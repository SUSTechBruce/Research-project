from Public.Individual import *
from Algorithms.NSGAII.tournament import tournament
from Algorithms.NSGAII.environment_selection import environment_selection
from Operators.GA import *

import time


class NSGAII(object):
    """
    NSGA-II algorithm
    """

    def __init__(self, pop_size, d, m, max_gen, pro):
        self.t = 0
        self.pop_size = pop_size
        self.d = d
        self.m = m
        self.max_gen = max_gen
        self.pro = pro

    @property
    def run(self):
        start = time.time()
        individual = Individual(self.pro)
        mos_pro, population = individual.initialize(self.d, self.pop_size, self.m)

        _, front_no, crowd_dis, _ = environment_selection(population, self.pop_size)

        pareto_f = mos_pro.pf()

        igd = []

        while self.t < self.max_gen:
            print('gen:' + str(self.t + 1))
            fit = np.vstack((front_no, -crowd_dis)).T
            mating_pool = tournament(2, self.pop_size, fit)
            parent = (population[0][mating_pool, :], population[1][mating_pool, :])
            offspring = GA(parent, boundary=(mos_pro.lower, mos_pro.upper))
            offspring = mos_pro.fit(operation='value', in_value=offspring)
            population = (np.vstack((population[0], offspring[0])),
                          np.vstack((population[1], offspring[1])))
            population, front_no, crowd_dis, _ = environment_selection(population, self.pop_size)
            igd.append(mos_pro.IGD(population[1]))
            self.t += 1
        igd = np.asarray(igd)
        print(time.time()-start)

        return population, igd, pareto_f


