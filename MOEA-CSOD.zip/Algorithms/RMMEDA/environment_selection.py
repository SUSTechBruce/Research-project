from Operators.NDSort import *


def crowding_distance(pop_obj):

    n, m = np.shape(pop_obj)

    crowd_dis = np.zeros(n)
    f_max = np.max(pop_obj, axis=0)
    f_min = np.min(pop_obj, axis=0)

    for i in range(m):
        rank = np.argsort(pop_obj[:, i])
        crowd_dis[rank[0]] = np.inf
        crowd_dis[rank[-1]] = np.inf
        for j in range(1, n-1):
            crowd_dis[rank[j]] = crowd_dis[rank[j]] + (pop_obj[rank[j+1], i] - pop_obj[rank[j-1], i])\
                                 / (f_max[i] - f_min[i])
    return crowd_dis


def environment_selection(population, N):
    front_no, max_front = nd_sort(population[1], N)
    next = front_no < max_front
    print(next)

    last = [i for i in range(len(front_no)) if front_no[i] == max_front]
    while len(last) > N - np.sum(next):
        worst = np.argmin(crowding_distance(population[1][last]))
        last = np.delete(last, last[worst])
    last = np.asarray(last)
    next[last] = True
    population = (population[0][next], population[1][next])

    return population


if __name__ == "__main__":
    a = np.array([[4, 12, 3], [2, 3, 5], [1, 4, 7], [4, 2, 5], [5, 7, 9], [6, 8, 9]])
    b = np.random.rand(6, 6)
    print(b)
    e = environment_selection((b, a), 3)
    print(e)
