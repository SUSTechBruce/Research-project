import numpy as np


def local_pca(pop_dec, M, K):
    global partition
    n, d = np.shape(pop_dec) # Dimensions
    model = [{'mean': pop_dec[k],  # The mean of the model
              'PI': np.eye(d),  # The matrix PI
              'e_vector': [],  # The eigenvectors
              'e_value': [],  # The eigenvalues
              'a': [],  # The lower bound of the projections
              'b': []} for k in range(K)]                           # The upper bound of the projections
    
    ## Modeling
    for iteration in range(50):
        # Calculte the distance between each solution and its projection in
        # affine principal subspace of each cluster
        distance = np.zeros((n, K))  # matrix of zeros N*K
        for k in range(K):
            distance[:, k] = np.sum((pop_dec - np.tile(model[k]['mean'], (n, 1))).dot(model[k]['PI'])
                                    * (pop_dec - np.tile(model[k]['mean'], (n, 1))), 1)
        # Partition
        partition = np.argmin(distance, axis=1)  # get the index of mins
        # Update the model of each cluster
        updated = np.zeros(K, dtype=bool)  # array of k false
        for k in range(K):
            old_mean = model[k]['mean']
            current = partition == k
            if sum(current) < 2:
                if not any(current):
                    current = [np.random.randint(n)]
                model[k]['mean'] = pop_dec[current, :]
                model[k]['PI'] = np.eye(d)
                model[k]['e_vector'] = []
                model[k]['e_value'] = []
            else:               
                model[k]['mean'] = np.mean(pop_dec[current, :], 0)
                cc = np.cov((pop_dec[current, :] - np.tile(model[k]['mean'], (np.sum(current), 1))).T)
                e_value, e_vector = np.linalg.eig(cc)
                rank = np.argsort(-e_value, axis=0)
                e_value = -np.sort(-e_value, axis=0)
                model[k]['e_value'] = np.real(e_value).copy()
                model[k]['e_vector'] = np.real(e_vector[:, rank]).copy()
                model[k]['PI'] = model[k]['e_vector'][:, (M-1):].dot(model[k]['e_vector'][:, (M-1):].conj().transpose())
                
            updated[k] = (not any(current)) or (np.sqrt(np.sum((old_mean-model[k]['mean'])**2)) > 1e-5)

        # Break if no change is made
        if not any(updated):
            break

    for k in range(K):
        if len(model[k]['e_vector']) != 0:
            hyper_rectangle = (pop_dec[partition == k, :] - np.tile(model[k]['mean'], (sum(partition == k), 1)))\
                .dot(model[k]['e_vector'][:, :M - 1])
            model[k]['a'] = np.min(hyper_rectangle, axis=0)  # this should by tested
            model[k]['b'] = np.max(hyper_rectangle, axis=0)  # this should by tested
        else:
            model[k]['a'] = np.zeros(M-1)
            model[k]['b'] = np.zeros(M-1)
 
    
    ## Calculate the probability of each cluster for reproduction
    # Calculate the volume of each cluster
    print(type(model[1]['a']))
    print(model[2]['a'])
    print(np.concatenate((model[1]['a'],model[2]['a'])))
    volume = np.asarray([model[k]['b'] for k in range(K)])-np.asarray([model[k]['a'] for k in range(K)])
#    volume = prod(cat(1,Model.b)-cat(1,Model.a),2)
    # Calculate the cumulative probability of each cluster
    print("v", volume)
    volume = np.prod(volume, axis=1)
    print(volume)
    probability = np.cumsum(volume/np.sum(volume))
    print(probability)

    return model, probability

