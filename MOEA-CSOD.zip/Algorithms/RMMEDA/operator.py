from Algorithms.RMMEDA.LocalPCA import *


def operator(*args):
    if len(args) < 2:
        K = 5
    else:
        K = args[1]
    pop = args[0]
    pop_dec, pop_obj = pop
    n, d = pop_dec.shape
    m = np.shape(pop_obj)[1]
    ## Modeling
    model, probability = local_pca(pop_dec, m, K)
    ## Reproduction
    offspring_dec = np.zeros((n, d))
    # Generate new trial solutions one by one
    for i in range(n):
        # Select one cluster by Roulette-wheel selection
        k = (np.where(np.random.rand() <= probability))[0][0]
        # Generate one offspring
        if len(model[k]['e_vector']) != 0:
            lower = model[k]['a'] - 0.25 * (model[k]['b'] - model[k]['a'])
            upper = model[k]['b'] + 0.25 * (model[k]['b'] - model[k]['a'])
            trial = np.random.rand(1, m-1) * (upper - lower) + lower  # ,(1,M-1)
            print("trial", trial)
            sigma = np.sum(np.abs(model[k]['e_value'][m - 1:d])) / (d - m + 1)
            print("sigma", sigma)
            print(model[k]['mean'])
            print(model[k]['e_vector'][:, :m - 1].conj().transpose())
            print(model[k]['e_vector'][:, :m - 1].transpose())
            print(trial * model[k]['e_vector'][:, :m - 1])
            print(trial * model[k]['e_vector'][:, :m - 1].conj().transpose())
            print(np.random.randn(d) * np.sqrt(sigma))
            offspring_dec[i, :] = model[k]['mean'] + trial * model[k]['e_vector'][:, :m - 1].conj().transpose() \
                                  + np.random.randn(d) * np.sqrt(sigma)
        else:
            offspring_dec[i, :] = model[k]['mean'] + np.random.randn(d)

    return offspring_dec


if __name__ == "__main__":
    a = np.array([[4, 12, 3], [2, 3, 5], [1, 4, 7], [4, 2, 5], [5, 7, 9], [6, 8, 9]])
    b = np.array([[4, 12, 3, 1], [2, 3, 5, 5], [1, 4, 7, 1], [4, 2, 5, 1], [5, 7, 9, 1], [6, 8, 9, 2]])
    e = operator((b, a))
    print(e)

