from Public.Individual import *
from Algorithms.RMMEDA.operator import *
from Algorithms.RMMEDA.environment_selection import *
from Operators.NDSort import *


class RMMEDA:

    def __init__(self, pop_size, d, m, max_gen, pro):
        self.t = 0
        self.pop_size = pop_size
        self.d = d
        self.m = m
        self.max_gen = max_gen
        self.pro = pro

    @property
    def optimization(self):
        individual = Individual(self.pro)
        mos_pro, population = individual.initialize(self.d, self.pop_size, self.m)
        pareto_f = mos_pro.pf()

        igd = []

        while self.t < self.max_gen:
            print('gen:' + str(self.t + 1))
            offspring = operator(population)
            population = EnvironmentalSelection().selection((np.vstack((population[0], offspring[0])),
                                                             np.vstack((population[1], offspring[1]))), self.popsize)
            igd.append(mos_pro.IGD(population[1]))
            print(igd)
            self.t += 1
        return population, igd, pareto_f