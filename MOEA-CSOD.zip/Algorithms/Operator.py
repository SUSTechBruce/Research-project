import numpy as np


class Operator:
    def __init__(self, loser, winner):
        self.loser = loser
        self.winner = winner

    def cso(self):
        n, d = np.shape(self.loser)
        loser_vel = np.zeros((n, d))
        winner_vel = np.zeros((n, d))

        r1 = np.tile(np.random.rand(n, 1), (1, d))
        r2 = np.tile(np.random.rand(n, 1), (1, d))
        off_vel = r1*loser_vel + r2*(self.winner - self.loser)
        off_dec = self.loser + off_vel + r1*(off_vel - loser_vel)

        off_dec = np.r_[off_dec, self.winner]
        off_vel = np.r_[off_vel, winner_vel]

        return off_dec, off_vel
