from Algorithms.EnvironmentalSelection import *
from Operators.PM_mutation import *
from Public.Individual import *
from Operators.Myplot import *
from Algorithms.Operator import *
from Operators.NDSort import *
import time
import random


def cal_fitness(pop_obj):
    n = len(pop_obj)
    fmax = np.max(pop_obj, axis=0)
    fmin = np.min(pop_obj, axis=0)
    pop_obj = (pop_obj - np.tile(fmin, (n, 1))) / np.tile(fmax - fmin, (n, 1))
    dis = np.full((n, n), np.inf)
    for i in range(n):
        s_pop_obj = np.maximum(pop_obj, np.tile(pop_obj[i, :], (n, 1)))
        for j in [k for k in range(n) if k != i]:
            dis[i, j] = np.linalg.norm(pop_obj[i, :] - s_pop_obj[j, :])
    fitness = np.min(dis, axis=1)
    return fitness


class LMOCSO:

    def __init__(self, pop_size, d, m, max_gen, pro):
        self.t = 0
        self.pop_size = pop_size
        self.d = d
        self.m = m
        self.max_gen = max_gen
        self.pro = pro

    @property
    def run(self):

        # generate population and reference vector
        individual = Individual(self.pro)
        v = uniform_point(self.pop_size, self.m)[0]
        mos_pro, population = individual.initialize(self.d, self.pop_size, self.m)
        ind = (nd_sort(population[1], 3)[0] == 1)
        print(ind)
        population = (population[0][ind], population[1][ind])
        population, _ = EnvironmentalSelection(population[0], population[1], v, (0 / self.max_gen)**2).selection()

        pareto_f = mos_pro.pf()

        igd = []

        # optimization
        while self.t < self.max_gen:
            # generate offspring
            print('gen:' + str(self.t + 1))
            fitness = cal_fitness(population[1])
            length = len(population[0])
            if length >= 2:
                rank = random.sample(range(length), int(np.floor(length / 2) * 2))
            else:
                rank = [0, 0]
            loser = np.asarray(rank[:int(len(rank) / 2)])
            winner = np.asarray(rank[int(len(rank) / 2):])
            change = fitness[loser] >= fitness[winner]
            temp = winner[change]
            winner[change] = loser[change]
            loser[change] = temp
            offspring, _ = Operator(population[0][loser], population[0][winner]).cso()
            offspring = pm_mutation(offspring, (mos_pro.lower, mos_pro.upper))
            offspring = mos_pro.fit(operation='value', in_value=offspring)
            ind = (nd_sort(offspring[1], 2)[0] == 1)
            offspring = (offspring[0][ind], offspring[1][ind])
            population, _ = EnvironmentalSelection(np.r_[population[0], offspring[0]],
                                                   np.r_[population[1], offspring[1]],
                                                   v, (self.t / self.max_gen)**2).selection()

            igd.append(mos_pro.IGD(population[1]))
            self.t += 1
            print("shape", np.shape(population[0]))
        igd = np.array(igd)
        return population, igd, pareto_f
