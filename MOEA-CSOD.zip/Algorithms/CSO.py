from Algorithms.Operator import *
import random
import numpy as np



def cal_fitness(pop_obj):
    n = len(pop_obj)
    fmax = np.max(pop_obj, axis=0)
    fmin = np.min(pop_obj, axis=0)
    pop_obj = (pop_obj - np.tile(fmin, (n, 1))) / np.tile(fmax - fmin, (n, 1))
    dis = np.full((n, n), np.inf)
    for i in range(n):
        s_pop_obj = np.maximum(pop_obj, np.tile(pop_obj[i, :], (n, 1)))
        for j in [k for k in range(n) if k != i]:
            dis[i, j] = np.linalg.norm(pop_obj[i, :] - s_pop_obj[j, :])
    fitness = np.min(dis, axis=1)
    return fitness

def cso(population):
    fitness = cal_fitness(population[1])
    length = len(population[0])
    if length >= 2:
        rank = random.sample(range(length), int(np.floor(length / 2) * 2))
    else:
        rank = [0, 0]
    loser = np.asarray(rank[:int(len(rank) / 2)])
    winner = np.asarray(rank[int(len(rank) / 2):])
    change = fitness[loser] >= fitness[winner]
    temp = winner[change]
    winner[change] = loser[change]
    loser[change] = temp
    offspring, _ = Operator(population[0][loser], population[0][winner]).cso()
    return offspring

