from Algorithms.CSO import *
from Networks.DAN import DAN
from Networks.WGAN import WGAN
import random
import numpy as np

class Offspring:
    def __init__(self, batch_size, dim_size):
        self.batch_size = batch_size
        self.dim_size = dim_size
        self.dan = DAN(self.batch_size, self.dim_size)
#        self.wgan = WGAN(self.batch_size, self.dim_size)
    
    def offspring(self, population):
        population_dan = self.dan.dan(population)
        population_cso = cso(population)
        
        lamda = random.uniform(0.2, 0.8)
        length = len(population[0])
        new_length = int(np.floor(lamda*length))
        population_fro = population_dan[:new_length]
        population_tail = population_cso[new_length:]
        population_dec = np.vstack([population_fro, population_tail])
        return population_dec