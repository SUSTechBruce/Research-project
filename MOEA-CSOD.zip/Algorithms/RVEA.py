from Algorithms.EnvironmentalSelection import *
from Algorithms.ReferenceVectorAdaptation import *
from Algorithms.Offspring import *
from Operators.PM_mutation import *
from Public.Individual import *
from Operators.Myplot import *
import time


class RVEA:

    def __init__(self, pop_size, d, m, max_gen, pro):
        self.t = 0
        self.pop_size = pop_size
        self.d = d
        self.m = m
        self.max_gen = max_gen
        self.pro = pro

    @property
    def run(self):
#        print(self.pro)
        alpha = 2
        fr = 0.1

        # generate population and reference vector
        individual = Individual(self.pro)
        mos_pro, population = individual.initialize(self.d, self.pop_size, self.m)

        pareto_f = mos_pro.pf()
        # wgan = WGAN(self.pop_size, self.d)
        offspring = Offspring(self.pop_size, self.d)
#        fake = (np.random.random([self.pop_size, self.d]), np.random.random([self.pop_size, mos_pro.m]))
        v = uniform_point(self.pop_size, self.m)[0]
        igd = []

        # optimization
        while self.t < self.max_gen:
            # generate offspring
#            print('gen:' + str(self.t+1))
            # offspring_dec = wgan.wgan_gp(population, fake)
            offspring_dec = offspring.offspring(population)

            mutation = pm_mutation(offspring_dec, (mos_pro.lower, mos_pro.upper))
            offspring_dec, offspring_obj = mos_pro.fit(operation='value', in_value=mutation)

            union_pop_dec = np.vstack([population[0], offspring_dec])
            union_pop_obj = np.vstack([population[1], offspring_obj])
            union_pop = (union_pop_dec, union_pop_obj)

            population, _ = EnvironmentalSelection(union_pop[0], union_pop[1],  v, (self.t/self.max_gen)**alpha)\
                .selection()
            if (self.t/self.max_gen) % fr == 0:
                v = ReferenceVectorAdaptation(population[1], v).adapter()

            igd.append(mos_pro.IGD(population[1]))
            self.t += 1
        igd = np.array(igd)
        return population, igd, pareto_f


