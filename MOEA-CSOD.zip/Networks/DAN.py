import argparse
import torch
from torch.autograd import Variable
import torch.autograd as autograd
from Networks import dan_model as dan
import numpy as np
import matplotlib
import os
import matplotlib.pyplot as plt
from IPython import display


class DAN:
    def __init__(self, batch_size, dim_size, noise_dim=256, epoch=20, model='dan_s'):
        self.dan_cuda = True if torch.cuda.is_available() else False
        self.dan_Tensor = torch.cuda.FloatTensor if self.dan_cuda else torch.FloatTensor
        self.batch_size = batch_size
        self.dim_size = dim_size
        self.noise_dim = noise_dim
        self.model = model
        self.generator = dan.Generator(self.noise_dim, self.dim_size)
        self.epoch = epoch
        self.lamda = 0#1e-5
        if model == 'dan_s':
            self.discriminator = dan.DS_Discriminator(self.dim_size)
        elif model == 'dan_2s':
            self.discriminator = dan.D2S_Discriminator(self.dim_size)
        else:
            self.discriminator = dan.DS_Discriminator(self.dim_size)
        if self.dan_cuda:
            self.generator.cuda()
            self.discriminator.cuda()
        self.optimizer_G = torch.optim.Adam(self.generator.parameters(), lr=1e-4, betas=(0.5, 0.999))
        self.optimizer_D = torch.optim.Adam(self.discriminator.parameters(), lr=1e-4, betas=(0.5, 0.999))

    def sample_Z(self, m, n):
        return np.random.normal(size=[m, n])

    def read(self):
        fid = open('circle.txt', 'r')
        lines = fid.readlines()
        data = []
        for line in lines:
            data.append([float(curr_num) for curr_num in line.split()])
        return np.array(data)

    def sigmoid(self, x):
        return 1 / (1 + torch.exp(-torch.abs(x)))

#    cross entropy
    def cross(self, x, y):
        return -(y * torch.log(x) + (1 - y) * torch.log(1 - x))

    def train(self, data, save=False):
        data_size = len(data)
        data = np.concatenate((data, data[:self.batch_size, :]), axis=0)
        if save:
            i = 0
            # matplotlib.use('Agg')
            save_fig_path = 'out_' + self.model
            if not os.path.exists(save_fig_path):
                os.makedirs(save_fig_path)
            plt.figure(figsize=(5, 5))
            plt.plot(data[:1000, 0], data[:1000, 1], 'b.')
            axes = plt.gca()
            axes.set_xlim([0, 1])
            axes.set_ylim([0, 1])
            plt.title('True data distribution')
            plt.savefig(save_fig_path + '/real.png', bbox_inches='tight', dpi=300)

            np_samples = []
            plot_every = 300
            plt.figure(figsize=(5, 5))

        for it in range(self.epoch):
            start_idx = it * self.batch_size % data_size
            X_mb = 2 * data[start_idx: start_idx + self.batch_size, :] - 1.
            Z = Variable(self.dan_Tensor(self.sample_Z(self.batch_size, self.noise_dim)))
            L1_loss = 0
            for param in self.generator.parameters():
                L1_loss += torch.sum(torch.abs(param))

            if self.model == 'dan_2s':
                sample_size = int(self.batch_size / 2)
                X_mb_1 = X_mb[:sample_size, :]
                X_mb_2 = X_mb[sample_size:, :]
                Z_1 = Z[:sample_size, :]
                Z_2 = Z[sample_size:, :]

                self.optimizer_D.zero_grad()
                real_X_1 = Variable(self.dan_Tensor(X_mb_1))
                real_X_2 = Variable(self.dan_Tensor(X_mb_2))
                fake_X_1 = self.generator(Z_1)
                fake_X_2 = self.generator(Z_2)
                d_logits_rr, d_logits_rf, d_logits_fr, d_logits_ff = self.discriminator(real_X_1, real_X_2, fake_X_1, fake_X_2)
                if self.dan_cuda:
                    like_rr = torch.zeros(d_logits_rr.size()[0], 1).cuda()
                    like_rf = torch.ones(d_logits_rf.size()[0], 1).cuda()
                    like_fr = torch.ones(d_logits_fr.size()[0], 1).cuda()
                    like_ff = torch.zeros(d_logits_ff.size()[0], 1).cuda()
                else:
                    like_rr = torch.zeros(d_logits_rr.size()[0], 1)
                    like_rf = torch.ones(d_logits_rf.size()[0], 1)
                    like_fr = torch.ones(d_logits_fr.size()[0], 1)
                    like_ff = torch.zeros(d_logits_ff.size()[0], 1)

                D_loss_rr = torch.mean(self.cross(d_logits_rr, like_rr))
                D_loss_rf = torch.mean(self.cross(d_logits_rf, like_rf))
                D_loss_fr = torch.mean(self.cross(d_logits_fr, like_fr))
                D_loss_ff = torch.mean(self.cross(d_logits_ff, like_ff))
                D_loss = 0.5 * (D_loss_rr + D_loss_rf + D_loss_fr + D_loss_ff) + self.lamda * L1_loss
                D_loss.backward()
                self.optimizer_D.step()

                real_X_1 = Variable(self.dan_Tensor(X_mb_1))
                real_X_2 = Variable(self.dan_Tensor(X_mb_2))
                fake_X_1 = self.generator(Z_1)
                fake_X_2 = self.generator(Z_2)
#                print(real_X_1[:20])
#                print(fake_X_1[:20])
                _, g_logits_rf, g_logits_fr, _ = self.discriminator(real_X_1, real_X_2, fake_X_1, fake_X_2)
                if self.dan_cuda:
                    like_gen_rf = torch.ones(g_logits_rf.size()[0], 1).cuda()
                    like_gen_fr = torch.zeros(g_logits_fr.size()[0], 1).cuda()
                else:
                    like_gen_rf = torch.ones(g_logits_rf.size()[0], 1)
                    like_gen_fr = torch.zeros(g_logits_fr.size()[0], 1)
                G_loss_rf = torch.mean(self.cross(g_logits_rf, like_gen_rf))
                G_loss_fr = torch.mean(self.cross(g_logits_fr, like_gen_fr))
                G_loss = G_loss_fr + G_loss_rf 
                G_loss.backward()
                self.optimizer_G.step()
#                print("D_loss",D_loss)
#                print("G_loss", G_loss)
            else:
                self.optimizer_D.zero_grad()
                real_X = Variable(self.dan_Tensor(X_mb))
                fake_X = self.generator(Z)
                d_logits_real = self.discriminator(real_X)
                d_logits_fake = self.discriminator(fake_X)
                if self.dan_cuda:
                    like_real = torch.ones(d_logits_real.size()[0], 1).cuda()
                    like_fake = torch.zeros(d_logits_fake.size()[0], 1).cuda()
                else:
                    like_real = torch.ones(d_logits_real.size()[0], 1)
                    like_fake = torch.zeros(d_logits_fake.size()[0], 1)

                D_loss_real = torch.mean(self.cross(d_logits_real, like_real))
                D_loss_fake = torch.mean(self.cross(d_logits_fake, like_fake))
                D_loss = D_loss_real + D_loss_fake + self.lamda * L1_loss
                D_loss.backward()
                self.optimizer_D.step()

                self.optimizer_G.zero_grad()
                g_logits = self.generator(Z)

#                print(real_X[:20])
#                print(g_logits[:20])
                g_logits_fake = self.discriminator(g_logits)
                if self.dan_cuda:
                    like_gen = torch.ones(g_logits.size()[0], 1).cuda()
                else:
                    like_gen = torch.ones(g_logits.size()[0], 1)
                G_loss = torch.mean(self.cross(g_logits_fake, like_gen)) 
                G_loss.backward()
                self.optimizer_G.step()
            # =============================================================================
            #     save figures of training
            # =============================================================================
            if save and (it + 1) % plot_every == 0:
                samples = self.generator(Variable(self.dan_Tensor(self.sample_Z(1000, self.noise_dim))))
                samples = samples.cpu().detach().numpy() if self.dan_cuda else samples.detach().numpy()
                samples = (samples + 1.0) / 2.
                np_samples.append(samples)
                plt.clf()
                plt.plot(samples[:, 0], samples[:, 1], 'b.')
                axes = plt.gca()
                axes.set_xlim([0, 1])
                axes.set_ylim([0, 1])
                plt.title('Iter: {}, loss(D): {:2.2f}, loss(G):{:2.2f}'.format(it + 1, D_loss, G_loss))
                plt.savefig('out_' + self.model + '/{}.png'.format(str(i).zfill(3)), bbox_inches='tight', dpi=300)
                display.display(plt.gcf())
                display.clear_output(wait=True)
                i += 1

    def dan(self, population=False, fake=False, save=False):
        # if population and fake:
        data = population[0]
        # else:
#        data = self.read()

        self.train(data, save)

        Z = Variable(self.dan_Tensor(self.sample_Z(self.batch_size, self.noise_dim)))
        population = self.generator(Z)
        population = population.cpu().detach().numpy() if self.dan_cuda else population.detach().numpy()
        return population


if __name__ == '__main__':
    a = 1
    mydan = DAN(512, 2, 256, 15000, 'dan_3s')
    a = mydan.dan(save=True)
    print(a)
