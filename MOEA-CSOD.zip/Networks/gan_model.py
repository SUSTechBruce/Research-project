import numpy as np

import torch.nn as nn
import torch.autograd as autograd
from torch.autograd import Variable
import torch


class Generator(nn.Module):

    def __init__(self, opt):
        super(Generator, self).__init__()

        def block(in_feat, out_feat):
            layers = [nn.Linear(in_feat, out_feat), nn.LeakyReLU(0.2, inplace=True)]
            return layers

        self.model = nn.Sequential(
            *block(opt.latent_dim, 2*opt.latent_dim),
            *block(2*opt.latent_dim, 4*opt.latent_dim),
            nn.Linear(4*opt.latent_dim, int(opt.ind_size)),
            nn.Tanh()
        )

    def forward(self, z):
        ind = self.model(z)
        return ind


class Discriminator(nn.Module):

    def __init__(self, opt):
        super(Discriminator, self).__init__()

        self.model = nn.Sequential(
            nn.Linear(int(opt.ind_size), 4*opt.latent_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(4*opt.latent_dim, 2*opt.latent_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(2*opt.latent_dim, 1),
        )

    def forward(self, ind):
        ind_flat = ind
        validity = self.model(ind_flat)
        return validity