import numpy as np

import torch.nn as nn
import torch.autograd as autograd
from torch.autograd import Variable
import torch


class Generator(nn.Module):

    def __init__(self, N, C):
        super(Generator, self).__init__()

        def block(in_feat, out_feat):
            layers = [nn.Linear(in_feat, out_feat)]
            layers.append(nn.ReLU())

            return layers

        self.model = nn.Sequential(
            *block(int(N), 128),
            *block(128, 128),
            *block(128, 128),
            nn.Linear(128, int(C)),
#            nn.Tanh()
            nn.Sigmoid()
        )

    def forward(self, z):
        ind = self.model(z)
        return ind


class Discriminator(nn.Module):

    def __init__(self, N):
        super(Discriminator, self).__init__()

        def block(in_feat, out_feat):
            layers = [nn.Linear(in_feat, out_feat)]
            layers.append(nn.ReLU())

            return layers

        self.model = nn.Sequential(
            *block(int(N), 32),
            *block(32, 32),
            *block(32, 32),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

    def forward(self, ind):
        validity = self.model(ind)
        return validity


class DS_Discriminator(nn.Module):

    def __init__(self, N):
        super(DS_Discriminator, self).__init__()

        def block(in_feat, out_feat):
            layers = [nn.Linear(in_feat, out_feat)]
            layers.append(nn.ReLU())

            return layers

        self.model1 = nn.Sequential(
            *block(int(N), 32),
            *block(32, 32)
        )
        self.model2 = nn.Sequential(
            *block(32, 32),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

    def forward(self, ind):
        temp = self.model1(ind)
        temp = torch.mean(temp, 0)
        validity = self.model2(temp)
        return validity


class D2S_Discriminator(nn.Module):

    def __init__(self, N):
        super(D2S_Discriminator, self).__init__()

        def block(in_feat, out_feat):
            layers = [nn.Linear(in_feat, out_feat)]
            layers.append(nn.ReLU())

            return layers

        self.model1 = nn.Sequential(
            *block(int(N), 32),
            *block(32, 32)
        )
        self.model2 = nn.Sequential(
            *block(32, 32),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )

    def forward(self, ind_r_1, ind_r_2, ind_f_1, ind_f_2):
        r_1 = torch.mean(self.model1(ind_r_1), 0)
        r_2 = torch.mean(self.model1(ind_r_2), 0)
        f_1 = torch.mean(self.model1(ind_f_1), 0)
        f_2 = torch.mean(self.model1(ind_f_2), 0)
        validity_rr = self.model2(torch.abs(r_2 - r_1))
        validity_rf = self.model2(torch.abs(r_2 - f_1))
        validity_fr = self.model2(torch.abs(f_2 - r_1))
        validity_ff = self.model2(torch.abs(f_2 - f_1))
        return validity_rr, validity_rf, validity_fr, validity_ff
