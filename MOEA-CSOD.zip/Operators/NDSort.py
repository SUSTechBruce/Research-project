import numpy as np


def ens_ss(pop_obj, n_sort):
    pop_obj, loc = np.unique(pop_obj, return_inverse=True, axis=0)
    table = np.histogram(loc, bins=range(max(loc) + 2))[0]
    N, M = np.shape(pop_obj)
    front_no = np.full(N, np.inf)
    max_fno = 0
    while np.sum(table[front_no < np.inf]) < np.minimum(n_sort, len(loc)):
        max_fno += 1
        for i in range(N):
            if front_no[i] == np.inf:
                dominated = False
                for j in range(i - 1, -1, -1):
                    if front_no[j] == max_fno:
                        m = 2
                        while m <= M and pop_obj[i, m - 1] >= pop_obj[j, m - 1]:
                            m += 1
                        dominated = m > M
                        if dominated or M == 2:
                            break
                if not dominated:
                    front_no[i] = max_fno
    front_no = front_no[loc]

    return front_no, max_fno


def t_enx(pop_obj, n_sort):
    pop_obj, loc = np.unique(pop_obj, return_inverse=True, axis=0)
    table = np.histogram(loc, bins=range(max(loc) + 2))[0]
    print("t", table)
    N, M = np.shape(pop_obj)
    front_no = np.full(N, np.inf)
    print(front_no)
    max_fno = 0
    forest = np.zeros(N).astype(int)
    children = np.zeros((N, M - 1))
    left_child = np.zeros(N) + M
    father = np.zeros(N)
    brother = np.zeros(N) + M
    o_rank = np.argsort(-pop_obj[:, 1:M + 1], axis=1)
    print("o", o_rank)
    o_rank += 1
    print(o_rank)
    while np.sum(table[front_no < np.inf]) < np.minimum(n_sort, len(loc)):
        max_fno += 1
        root = np.where(front_no == np.inf)[0][0]
        print("root", root)
        forest[max_fno] = root
        front_no[root] = max_fno
        for p in range(N):
            if front_no[p] == np.inf:
                pruning = np.zeros((1, N))
                q = forest[max_fno]
                print("q", q)
                while True:
                    m = 1
                    while m < M and pop_obj[p, o_rank[q, m - 1]] >= pop_obj[q, o_rank[q, m - 1]]:
                        m += 1
                    if m == M:
                        break
                    else:
                        pruning[q] = m
                        if left_child[q] <= pruning[q]:
                            q = children[q, left_child[q]]
                        else:
                            while father[q] and brother[q] > pruning[father[q]]:
                                q = father[q]
                            if father[q]:
                                q = children[father[q], brother[q]]
                            else:
                                break
                if m < M:
                    front_no[p] = max_fno
                    q = forest[max_fno]
                    while children[q, pruning[q]]:
                        q = children[q, pruning[q]]
                    children[q, pruning[q]] = p
                    father[p] = q
                    if left_child[q] > pruning[q]:
                        brother[p] = left_child[q]
                        left_child[q] = pruning[q]
                    else:
                        bro = children[q, left_child[q]]
                        while brother[bro] < pruning[q]:
                            bro = children[q, brother[bro]]
                        brother[p] = brother[bro]
                        brother[bro] = pruning[q]

    front_no = front_no[loc]

    return front_no, max_fno


def nd_sort(*args):
    pop_obj = args[0]
    n, m = np.shape(pop_obj)
    if len(args) == 2:
        n_sort = args[1]
    else:
        pop_con = args[1]
        n_sort = args[2]
        infeasible = np.any(pop_con, axis=1)
        pop_obj[infeasible, :] = np.tile(np.max(pop_obj, axis=0), (np.sum(infeasible), 1)) + \
            np.tile(np.sum(np.maximum(0, pop_con[infeasible, :]), axis=1, keepdims=True), (1, m))
    if m < 5 or n < 500:
        front_no, max_fno = ens_ss(pop_obj, n_sort)
    else:
        front_no, max_fno = t_enx(pop_obj, n_sort)

    return front_no, max_fno
