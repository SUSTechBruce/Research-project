import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def plot(obj, pf, figure):
    n, m = np.shape(obj)
    if m == 3:
        x = obj[:, 0]
        y = obj[:, 1]
        z = obj[:, 2]
        fig = plt.figure()
        ax = Axes3D(fig)
        ax.scatter(x, y, z, s=5, c='gray', marker='o')
        ax.set_xlabel('f1')
        ax.set_ylabel('f2')
        ax.set_zlabel('f3')
        plt.savefig(figure, dpi=300)
    if m > 3:
        x = range(1, m+1)
        for i in range(n):
            plt.plot(x, obj[i, :], c='gray')
        plt.xlabel('Dimension No.')
        plt.ylabel('Value')
        plt.savefig(figure, dpi=300)

