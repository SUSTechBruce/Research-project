import numpy as np


def GA(pop, boundary = None):
    """
    Generate offspring individuals
    :param boundary: lower and upper boundary of pop_dec once d != self.d
    :param pop_dec: decision vectors
    :return:
    """
    pro_c = 1
    dis_c = 20
    pro_m = 1
    dis_m = 20
    pop_dec = pop[0]
    # pop_dec = pop_dec[:(len(pop_dec) // 2) * 2][:]
    n, d = np.shape(pop_dec)
    parent_1_dec = pop_dec[:n // 2, :]
    parent_2_dec = pop_dec[n // 2:n // 2 * 2, :]
    n, d = np.shape(parent_1_dec)
    beta = np.zeros((n, d))
    mu = np.random.random((n, d))
    beta[mu <= 0.5] = np.power(2 * mu[mu <= 0.5], 1 / (dis_c + 1))
    beta[mu > 0.5] = np.power(2 - 2 * mu[mu > 0.5], -1 / (dis_c + 1))
    beta = beta * ((-1) ** np.random.randint(2, size=(n, d)))
    beta[np.random.random((n, d)) < 0.5] = 1
    beta[np.tile(np.random.random((n, 1)) > pro_c, (1, d))] = 1
    offspring_dec = np.vstack(((parent_1_dec + parent_2_dec) / 2 + beta * (parent_1_dec - parent_2_dec) / 2,
                               (parent_1_dec + parent_2_dec) / 2 - beta * (parent_1_dec - parent_2_dec) / 2))
    site = np.random.random((2*n, d)) < pro_m / d
    mu = np.random.random((2*n, d))
    temp = site & (mu <= 0.5)

    lower, upper = np.tile(boundary[0], (2*n, 1)), np.tile(boundary[1], (2*n, 1))

    norm = (offspring_dec[temp] - lower[temp]) / (upper[temp] - lower[temp])
    offspring_dec = np.minimum(np.maximum(offspring_dec, lower), upper)
    offspring_dec[temp] += (upper[temp] - lower[temp]) * \
                           (np.power(2. * mu[temp] + (1. - 2. * mu[temp]) * np.power(1. - norm, dis_m + 1.),
                                     1. / (dis_m + 1)) - 1.)
    temp = site & (mu > 0.5)
    norm = (upper[temp] - offspring_dec[temp]) / (upper[temp] - lower[temp])
    offspring_dec[temp] += (upper[temp] - lower[temp]) * \
                           (1. - np.power(
                               2. * (1. - mu[temp]) + 2. * (mu[temp] - 0.5) * np.power(1. - norm, dis_m + 1.),
                               1. / (dis_m + 1.)))
    return offspring_dec
