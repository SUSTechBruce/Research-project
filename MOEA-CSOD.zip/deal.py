import os
import scipy.io as sio
#Data/' + a + '_{0}_{1}'.format(b, i+1)
path = os.path.abspath('.')
path = os.path.join(path, 'Data')
print(path)
a = os.walk(path)
files = next(a)[2]
#print(files)
#temp = sio.loadmat('LSMOP1_3_1')
#print(temp)

new_txt = open('new.txt', 'w')
for file in files:
    info = file.split('_')
    file_path = os.path.join(path, file)
    temp = sio.loadmat(file_path)
#    print(float(temp['igd_last'][0][0]))
#    print(info)
    myString = info[0] + "\t" + info[1] + "\t" + info[2] +"\t" + str(float(temp['igd_last'][0][0])) + "\n\n"
#    print(myString)
#    break
    new_txt.write(myString)
new_txt.close()
