from Algorithms.RVEA import *
from Algorithms.LMOCSO import *
from Algorithms.NSGAII.NSGAII import *
import time
import scipy.io as sio
import os
#'LSMOP6',
parameter = {'algorithm': 'LMOCSO', 'problem': ['LSMOP9'],#[ 'LSMOP1', 'LSMOP2', 'LSMOP3', 'LSMOP4','LSMOP5', 'LSMOP6', 'LSMOP7', 'LSMOP8'],
             'max_gen': 50, 'N': 105, 'M and N': [[3,105], [6,132], [8,156], [10,275]], 'D': 100 , 'run': 10}
#parameter = {'algorithm': 'RVEA', 'problem': ['LSMOP6'],
#             'max_gen': 50, 'N': 105, 'M': [3], 'D': 100, 'run': 1}
# parameter = {'algorithm': 'NSGAII', 'problem': 'LSMOP1',
#              'max_gen': 50, 'N': 105, 'M': 3, 'D': 300, 'run': 1}

start = time.time()
path = os.path.abspath('.')
for a in parameter['problem']:
    for b in parameter['M and N']:
        for i in range(parameter['run']):
            m = b[0]
            n = b[1]
            print("Run ", str(i+1), " problem_", a, " M_", m," N_", n)
            name = path + '/Data/' + a + '_{0}_{1}'.format(b, i+1)
            fig = path + '/Graph/' + a + '_{0}_{1}.png'.format(b, i+1)
            #    lmosco = LMOCSO(parameter['N'], parameter['D'], parameter['M'], parameter['max_gen'], parameter['problem'])
            rvea = RVEA(n, 100 * m, m, parameter['max_gen'], a)
            # nsgaii = NSGAII(parameter['N'], parameter['D'], parameter['M'], parameter['max_gen'], parameter['problem'])
            #    pop, igd, pf = lmosco.run
            pop, igd, pf = rvea.run
            # pop, igd, pf = nsgaii.run
#            print(pf)
#            print(np.shape(pop[1]))
#            print(igd)
#            sio.savemat(name, {'obj': 1})
            sio.savemat(name, {'obj': pop[1], 'igd_last': igd[-1], 'igd': igd, 'pf': pf})
            plot(pop[1], pf, fig)
time = time.time() - start
print(time)
