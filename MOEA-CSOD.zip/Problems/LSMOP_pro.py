from Public.uniformweight import *
from scipy.spatial.distance import cdist
import numpy as np


class Testproblem(object):
    def __init__(self, m=None, d=None, ref_num=100):
        self.nk = 5
        if m is None:
            self.m = 3
        else:
            self.m = m

        if d is None:
            self.d = self.m * 100
        else:
            self.d = d
        self.lower = np.zeros([1, self.d])
        self.upper = np.c_[np.ones([1, self.m - 1]), 10 * np.ones([1, self.d - self.m + 1])]
        self.ref_num = ref_num
        # Calculate the number of variables in each
        c = [3.8 * 0.1 * (1 - 0.1)]
        tmp = [3.8 * 0.1 * (1 - 0.1)]
        for i in range(1, self.m):
            c.append(3.8 * c[- 1] * (1 - c[-1]))
        c = np.asarray(c)
        self.sublen = np.floor(c / np.sum(c) * self.d / self.nk)
        self.len_ = np.r_[0, np.cumsum(self.sublen * self.nk)]

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random((in_value, self.d)) * \
                       np.tile(self.upper - self.lower, (in_value, 1)) + \
                       np.tile(self.lower, (in_value, 1))
        pop_obj = np.zeros((np.shape(in_value)[0], self.m))

        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        return f

    def IGD(self, pop_obj):
        return np.mean(np.amin(cdist(self.pf(), pop_obj), axis=1))


class LSMOP1(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)), in_value[:, :m - 1]], axis=1)) * np.c_[
            np.ones((n, 1)), 1 - in_value[:, m - 2::-1]]
        return in_value, pop_obj


def Sphere(x):
    return np.sum(x ** 2, axis=1, keepdims=True)


class LSMOP2(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Giewank(in_value[:,
                                                        int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                            self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Schwefel(in_value[:,
                                                         int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                             self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)), in_value[:, :m - 1]], axis=1)) * np.c_[
            np.ones((n, 1)), 1 - in_value[:, m - 2::-1]]
        return in_value, pop_obj


def Giewank(x):
    f = np.sum(x ** 2, axis=1, keepdims=True) / 4000 - np.prod(
        np.cos(x / np.tile(np.sqrt(np.arange(1, np.shape(x)[1] + 1)), (np.shape(x)[0], 1))), axis=1, keepdims=True) + 1
    return f


# def Schwefel(x):
#     f = []
#     row = np.shape(x)[0]
#     Y = np.abs(x).max(axis=1)
#     I = []
#     for i in range(row):
#         I.append(np.abs(x[i]).tolist().index(Y[i]))
#     f.append(Y.tolist())
#     f = np.mat(f)
#     return np.transpose(f)

def Schwefel(x):

    return np.max(np.abs(x), keepdims=True, axis=1)


class LSMOP3(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Rastrigin(in_value[:,
                                                          int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                              self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Rosenbrock(in_value[:,
                                                           int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                               self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)), in_value[:, :m - 1]], axis=1)) * np.c_[
            np.ones((n, 1)), 1 - in_value[:, m - 2::-1]]
        return in_value, pop_obj


def Rastrigin(x):
    f = np.sum(x ** 2 - 10 * np.cos(2 * np.pi * x) + 10, axis=1, keepdims=True)
    return f


def Rosenbrock(x):
    f = np.sum(
        100 * ((x[:, :np.shape(x)[1] - 1]) ** 2 - x[:, 1:np.shape(x)[1]]) ** 2 + (x[:, :np.shape(x)[1] - 1] - 1) ** 2,
        axis=1, keepdims=True)
    return f


class LSMOP4(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Ackley(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Griewank(in_value[:,
                                                         int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                             self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)), in_value[:, :m - 1]], axis=1)) * np.c_[
            np.ones((n, 1)), 1 - in_value[:, m - 2::-1]]
        return in_value, pop_obj


def Ackley(x):

    np.seterr(divide='ignore', invalid='ignore')
    f = 20 - 20 * np.exp(-0.2 * np.sqrt(np.sum(x ** 2, axis=1, keepdims=True) / np.shape(x)[1])) - np.exp(
        np.sum(np.cos(2 * np.pi * x), axis=1, keepdims=True) / np.shape(x)[1]) + np.exp(1)
    if np.isnan(f[0]):
        f = np.zeros([np.shape(f)[0], np.shape(f)[1]])
    return f


def Griewank(x):
    f = np.sum(x ** 2, axis=1, keepdims=True) / 4000 - np.prod(
        np.cos(x / np.tile(np.sqrt(np.arange(1, np.shape(x)[1] + 1)), (np.shape(x)[0], 1))), axis=1, keepdims=True) + 1
    return f


class LSMOP5(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1) / d * np.pi / 2), (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        # index = np.where(self.sublen == 0)
        # if len(index[0]) != 0:
        #     g[:, index] = 0
        pop_obj = (1 + g + np.c_[g[:, 1:], np.zeros((n, 1))]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1] * np.pi / 2)], axis=1)) * np.c_[
                      np.ones((n, 1)), np.sin(in_value[:, m - 2::-1] * np.pi / 2)]

        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        f = f / np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
        return f


class LSMOP6(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1) / d * np.pi / 2), (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros((n, m))
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Rosenbrock(in_value[:,
                                                           int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                               self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Schwefel(in_value[:,
                                                         int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                             self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g + np.c_[g[:, 1:], np.zeros([n, 1])]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1] * np.pi / 2)], axis=1)) * np.c_[
                      np.ones((n, 1)), np.sin(in_value[:, m - 2::-1] * np.pi / 2)]
        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        f = f / np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
        return f


class LSMOP7(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1) / d * np.pi / 2), (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Ackley(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Rosenbrock(in_value[:,
                                                           int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                               self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g + np.c_[g[:, 1:], np.zeros([n, 1])]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1] * np.pi / 2)], axis=1)) * np.c_[
                      np.ones((n, 1)), np.sin(in_value[:, m - 2::-1] * np.pi / 2)]
        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        f = f / np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
        return f


class LSMOP8(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1) / d * np.pi / 2), (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Griewank(in_value[:,
                                                         int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                             self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g + np.c_[g[:, 1:], np.zeros([n, 1])]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1] * np.pi / 2)], axis=1)) * np.c_[
                      np.ones((n, 1)), np.sin(in_value[:, m - 2::-1] * np.pi / 2)]
        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        f = f / np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
        return f


class LSMOP9(Testproblem):
    def __init__(self, m, d, ref_num):
        self.N = 0
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        temp = in_value
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        self.N = n
        m = self.m
        # print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        # print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        # PopDec(:,M:D) = (1+repmat(cos((M:D)./D*pi/2),N,1)).*PopDec(:,M:D) - repmat(PopDec(:,1)*10,1,D-M+1);
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1) / d * np.pi / 2), (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        # in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
        #     in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros((n, m))
        for i in range(0, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            for j in range(1, self.nk+1):
                g[:, i:i + 1] = g[:, i:i + 1] + Ackley(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        # G = 1 + sum(G./repmat(obj.sublen,N,1)./obj.nk,2);
        g = 1 + np.sum(g / np.tile(self.sublen, (n, 1)) / self.nk, axis=1, keepdims=True)
        # pop_obj = np.random.random([temp, self.d])  # may have error
        pop_obj = np.zeros((n, m))
        # print("temp", temp)
        # print("D", self.d)
        # pop_obj[:, :m - 1] = in_value[:, :m - 1]
        # print("----22", pop_obj.shape)
        # print("b SHAPE", pop_obj[:, :m - 1].shape)
        pop_obj[:, :m-1] = in_value[:, :m-1]
        # print(pop_obj[:, :m - 1].shape)
        # print((1 + np.tile(g, (1, m - 1))).shape)
        pop_obj[:, m-1:m] = (1 + g) * (m - np.sum(
            pop_obj[:, :m - 1] / (1 + np.tile(g, (1, m - 1))) * (1 + np.sin(3 * np.pi * pop_obj[:, :m - 1])), axis=1, keepdims=True))
        # print("X SHAOE", pop_obj[:, m-1:m].shape)
        return in_value, pop_obj

    def pf(self):
        interval = [0, 0.251412, 0.631627, 0.859401]
        median = (interval[1] - interval[0]) / (interval[3] - interval[2] + interval[1] - interval[0])
        X = ReplicatePoint(self.N, self.m - 1)
        # print("x", X)
        X[X <= median] = X[X <= median] * (interval[1] - interval[0]) / median + interval[0]
        X[X > median] = (X[X > median] - median) * (interval[3] - interval[2]) / (1 - median) + interval[2]
        p = np.c_[X, 2 * (self.m - np.sum(X / 2 * (1 + np.sin(3 * np.pi * X)), axis=1, keepdims=True))]
        return p


# def ReplicatePoint(SampleNum, M):
#     if M > 1:
#         W = np.zeros((2 ** M, M))
#         for j in range(0, M):
#             for i in range(0, 2 ** M):
#                 if i % 2 ** (j + 1) == 0:
#                     for k in range(0, 2 ** j):
#                         W[i - k - 1][j] = 1
#
#     else:
#         W = (np.arange(0, 1, 1 / (SampleNum - 1))).T
#     return W

def ReplicatePoint(sample_num, M):
    if M > 1:
        sample_num = np.ceil(sample_num**(1/M))**M
        gap = np.arange(0, 1 + 1e-10, 1/(sample_num**(1/M)-1))
        length = len(gap)
        w = np.zeros((length ** M, M))
        s = "gap," * M
        statement = "np.meshgrid(" + s + ")"
        a = eval(statement)
        # print(a)
        w[:, 0] = a[1][:].flatten('F')
        w[:, 1] = a[0][:].flatten('F')
        for i in range(2, M):
            w[:, i] = a[i][:].flatten('F')

    else:
        w = (np.arange(0, 1+ 1e-10, 1 / (sample_num - 1))).transpose()
    return w


if __name__ == "__main__":
    r = LSMOP9(3, 300, 10000)
    i, p = r.fit('init', 105)
    pf = r.pf()
    print(pf)
    print(np.shape(i))
    n, m = np.shape(pf)

    # x = pf[:, 0]
    # y = pf[:, 1]
    # z = pf[:, 2]
    # fig = plt.figure()
    # ax = Axes3D(fig)
    # ax.scatter(x, y, z, c='r')
    # ax.set_xlabel('f1')
    # ax.set_ylabel('f2')
    # ax.set_zlabel('f3')
    # plt.savefig("dtlz1_std.png", dpi=300)
    # plt.show()

    x = range(1, m + 1)
    # for i in range(n):
    #     plt.plot(x, pf[i, :])
    # plt.xlabel('Dimension No.')
    # plt.ylabel('Value')
    # plt.show()
    # plt.savefig("dtlz1_4.png", dpi=300)

    # print(pf)
    igd = r.IGD(p)
    # print(i)
    print(p)
    print(igd)