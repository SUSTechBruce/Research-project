import numpy as np
from Public.uniformweight import uniform_point
from scipy.spatial.distance import cdist


class TestProblem(object):
    def __init__(self, m=None, d=None, ref_num=100, k=None):
        if m is None:
            self.m = 3
        else:
            self.m = m

        if d is None:
            self.d = self.m + 9
        else:
            self.d = d

        self.k = self.m - 1
        self.lower = np.zeros([1, self.d])
        self.upper = np.array(np.arange(2, 2*self.m, 2))
        self.ref_num = ref_num

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random((in_value, self.d)) * \
                       np.tile(self.upper - self.lower, (in_value, 1)) + \
                       np.tile(self.lower, (in_value, 1))
        pop_obj = np.zeros((np.shape(in_value)[0], self.m))

        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0]
        c = np.ones((np.shape(f)[0], self.m))
        for i in range(np.shape(f)[0]):
            for j in range(1, self.m):
                temp = f[i, j]/f[i, 0]*np.prod(1-c[i, self.m-j+2:self.m-1]) # may have index bug
                c[i, self.m-j+1] = (temp**2 - temp + np.sqrt(2*temp)/(temp**2 + 1))
        x = np.arccos(c)*2/np.pi
        temp = (1 - np.sin(np.pi/2*x[:, 1])) * f[:, self.m-1]/f[:, self.m-2]
        a = np.arange(0, 1, .0001)
        E = np.abs(temp*(1-np.cos(np.pi/2*a))-1+np.tile(a+np.cos(10*np.pi*a+np.pi/2), (np.shape(x)[0], 1)))
        rank = np.argsort(E, axis=1)
        for i in range(np.shape(x)[0]):
            x[i, 1] = a[np.min(rank[i, :10])]
        f = convex(f)
        f[:, self.m] = mixed(f)
        f = np.tile(np.arange(2, 2*self.m, 2), (np.shape(f)[0], 1))*f
        return f

    def IGD(self, pop_obj):
        return np.mean(np.amin(cdist(self.pf(), pop_obj), axis=1))


class WFG1(TestProblem):
    def __init__(self, m, d, ref_num, k):
        TestProblem.__init__(self, m, d, ref_num, k)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        k = self.k
        l = d - k
        d = 1
        s = np.arange(2, 2*m+1, 2)
        a = np.ones((1, m-1))
        z01 = in_value/np.tile(np.arange(2, 2*np.shape(in_value)[1]+1, 2), (n, 1))

        t1 = np.zeros((n, k + l))
        t1[:, :k] = z01[:, :k]
        t1[:, k:] = s_linear(z01[:, k:], 0.35)

        t2 = np.zeros((n, k + l))
        t2[:, :k] = t1[:, :k]
        t2[:, k:] = b_flat(t1[:, k:], 0.8, 0.75, 0.85)

        t3 = np.zeros((n, k + l))
        t3 = b_poly(t2, 0.02)

        t4 = np.zeros((n, m))
        for i in range(m-1):
            print(int(((i-1)*k/(m-1)+1)))
            print(int(i*k/(m-1)))
            t4[:, i] = r_sum(t3[:, int(((i-1)*k/(m-1)+1)):int(i*k/(m-1))], np.arange(2*((i-1)*k/(m-1)+1), 2*i*k/(m-1), 2))[0]
        t4[:, m-1] = r_sum(t3[:, k:k+l], np.arange(2*(k+1), 2*(k+l)+1, 2))[0]

        print(t4)
        x = np.zeros((n, m))
        for i in range(m-1):
            temp = t4[:, m-1]
            for j in range(np.shape(temp)[0]):
                if temp[j] < a[0, i]:
                    temp[j] = a[0, i]

            x[:, i] = temp * (t4[:, i]-0.5)+0.5
        x[:, m-1] = t4[:, m-1]
        print(x)
        h = convex(x)
        print(d*x[:, m-1])
        h[:, m-1] = mixed(x)
        obj = np.tile(d*x[:, m-1], (1, m)) + np.tile(s, (n, 1))*h

        return in_value, obj


def s_linear(y, a):
    return np.abs(y - a) / np.abs(np.floor(a - y) + a)


def b_flat(y, a, b, c):
    output = a + a*(((np.floor(y-b) < 0)*np.floor(y-b)) * (b-y)/b -
                    (1-a)*((np.floor(c-y) < 0)*np.floor(c-y)) * (y-c)/1-c)
    return np.around(output, 6)


def b_poly(y, a):
    return y**2


def r_sum(y, w):
    return np.sum(y*np.tile(w, (np.shape(y)[0], 1)), axis=1, keepdims=True)/np.sum(w)


def convex(x):
    return np.fliplr(np.cumprod(np.c_[np.ones((np.shape(x)[0], 1)), 1-np.cos(x[:, :-1]*np.pi/2)], axis=1)) *\
           np.c_[np.ones((np.shape(x)[0], 1)), 1-np.sin(x[:, -2::-1]*np.pi/2)]


def mixed(x):
    return 1-x[:, 0]-np.cos(10*np.pi*x[:, 0]+np.pi/2)/10/np.pi


if __name__ == "__main__":
    r = WFG1(3, 10, 10, 1)
    i, p = r.fit('init', 10)
    pf = r.pf()


    print(pf)
    igd = r.IGD(p)
    print(i)
    print(p)
    print(igd)