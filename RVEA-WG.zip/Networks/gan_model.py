import numpy as np

import torch.nn as nn
import torch.autograd as autograd
from torch.autograd import Variable
import torch


class Generator(nn.Module):

    def __init__(self, opt):
        super(Generator, self).__init__()

        def block(in_feat, out_feat, normalize = True):
            layers = [nn.Linear(in_feat, out_feat)]
            '''
            if normalize:
                layers.append(nn.BatchNorm1d(out_feat, 0.8))
            '''
            layers.append(nn.LeakyReLU(0.2, inplace=True))
            
            return layers

        self.model = nn.Sequential(
            *block(opt.latent_dim, 128),
            *block(128, 256),
            nn.Linear(256, int(opt.ind_size)),
            nn.Sigmoid()
        )

    def forward(self, z):
        ind = self.model(z)
        #print("\nind\n",ind)
        return ind


class Discriminator(nn.Module):

    def __init__(self, opt):
        super(Discriminator, self).__init__()

        self.model = nn.Sequential(
            nn.Linear(int(opt.ind_size), 256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(256, 128),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(128, 1),
        )

    def forward(self, ind):
        ind_flat = ind
        validity = self.model(ind_flat)
        return validity