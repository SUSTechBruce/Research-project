import argparse
import numpy as np

from torch.utils.data import DataLoader
from torch.autograd import Variable

import torch.autograd as autograd
import torch

from Networks import gan_model as gan
#import gan_model as gan
import matplotlib.pyplot as plt

class WGAN():

    def __init__(self, size, d):
        parser = argparse.ArgumentParser()
        parser.add_argument("--n_epochs", type=int, default=40, help="number of epochs of training")
        parser.add_argument("--batch_size", type=int, default=16, help="size of the batches")
        parser.add_argument("--lr", type=float, default=0.0001, help="adam: learning rate")
        parser.add_argument("--b1", type=float, default=0.9, help="adam: decay of first order momentum of gradient")
        parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
        #parser.add_argument("--n_cpu", type=int, default=8, help="number of cpu threads to use during batch generation")
        parser.add_argument("--latent_dim", type=int, default=7, help="dimensionality of the latent space")
        parser.add_argument("--ind_size", type=int, default=28, help="size of each individual dimension")
        #parser.add_argument("--channels", type=int, default=1, help="number of image channels")
        parser.add_argument("--n_critic", type=int, default=2,
                            help="number of training steps for discriminator per iter")
        parser.add_argument("--clip_value", type=float, default=0.01,
                            help="lower and upper clip value for disc. weights")
        #parser.add_argument("--sample_interval", type=int, default=1, help="interval betwen samples")
        self.opt = parser.parse_args()
        self.opt.ind_size = d
        self.t = 0
        self.pop_size = size
        #self.batch_size = size
        self.cuda = True if torch.cuda.is_available() else False
        self.Tensor = torch.cuda.FloatTensor if self.cuda else torch.FloatTensor
        self.loss_data = np.zeros([2, 1 + self.opt.n_epochs * int(self.pop_size/self.opt.batch_size/self.opt.n_critic)])

        self.generator = gan.Generator(self.opt)
        self.discriminator = gan.Discriminator(self.opt)
        if self.cuda:
            self.generator.cuda()
            self.discriminator.cuda()
        self.optimizer_G = torch.optim.Adam(self.generator.parameters(), lr=self.opt.lr,
                                            betas=(self.opt.b1, self.opt.b2))
        self.optimizer_D = torch.optim.Adam(self.discriminator.parameters(), lr=self.opt.lr,
                                            betas=(self.opt.b1, self.opt.b2))

    def pre_train(self, pop_r, pop_f):
        pop_good = pop_r
        good_size = pop_good.shape[0]
        # print(pop_good.shape)
        pop_bad = pop_f
        bad_size = pop_bad.shape[0]
        if good_size > bad_size:
            temp = np.random.rand(good_size - bad_size, self.opt.ind_size)
            #print("temp", temp.shape)
            #print("bad", pop_bad.shape)
            pop_bad = np.vstack((pop_bad, temp))
            pop_bad = torch.from_numpy(pop_bad)
        # print(pop_bad.shape)
        total_size = pop_good.shape[0]
        order = np.arange(total_size)
        np.random.shuffle(order)
        order = torch.from_numpy(order)
        if self.cuda:
            order = order.cuda()
        torch_dataset = torch.utils.data.TensorDataset(pop_good, order)
        dataloader = torch.utils.data.DataLoader(
            torch_dataset,
            batch_size=self.opt.batch_size,
            shuffle=True,
        )
        lambda_gp = 10  

        for i, (imgs, _) in enumerate(dataloader):
            # Configure input
            real_imgs = Variable(imgs.type(self.Tensor))

            # ---------------------
            #  Train Discriminator
            # ---------------------

            self.optimizer_D.zero_grad()
            # print("real",real_imgs.shape)
            # Sample noise as generator input

            # print("z",z.shape)
            # Generate a batch of images
            fake_imgs = Variable(pop_bad[i].type(self.Tensor))
            # print("fake",fake_imgs.shape)

            # Real images
            real_validity = self.discriminator(real_imgs)
            # Fake images
            fake_validity = self.discriminator(fake_imgs)
            # Gradient penalty
            gradient_penalty = self.compute_gradient_penalty(self.discriminator, real_imgs.data, fake_imgs.data)
            # Adversarial loss
            d_loss = -torch.mean(real_validity) + torch.mean(fake_validity) + lambda_gp * gradient_penalty

            d_loss.backward()
            self.optimizer_D.step()

    def wgan_gp(self, pop, fake):

        total_size = pop[0].shape[0]
        pop_r = torch.from_numpy(pop[0])
        #print("pop_r", pop_r)

        pop_f = torch.from_numpy(fake[0])
        if self.cuda:
            pop_r = pop_r.cuda()
            pop_f = pop_f.cuda()
        if self.t:
            self.pre_train(pop_r, pop_f)
        #print("total1", total_size)
        #print("batch_size1", self.opt.batch_size)
        torch_dataset = torch.utils.data.TensorDataset(pop_r, torch.linspace(1, total_size, total_size))
        self.train(torch_dataset)

        z = Variable(self.Tensor(np.random.randn(self.pop_size, self.opt.latent_dim)))
        offspring = self.generator(z)
        offspring = offspring.cpu()
        offspring = offspring.data.numpy()
        # offspring = np.abs(offspring)
        offspring = offspring
        #print("offspring\t", offspring.shape)

        return offspring

    def compute_gradient_penalty(self, D, real_samples, fake_samples):
        """Calculates the gradient penalty loss for WGAN GP"""
        # Random weight term for interpolation between real and fake samples
        alpha = self.Tensor(np.random.random((real_samples.size(0), 1,)))
        # print("real",real_samples.shape)
        # print("fake",fake_samples.shape)
        # Get random interpolation between real and fake samples
        interpolates = (alpha * real_samples + ((1 - alpha) * fake_samples)).requires_grad_(True)
        # print("inter.data",interpolates.data)
        # print("inter",interpolates)
        d_interpolates = D(interpolates)
        fake = Variable(self.Tensor(real_samples.shape[0], 1).fill_(1.0), requires_grad=False)
        # print("fake", fake)
        # Get gradient w.r.t. interpolates
        gradients = autograd.grad(
            outputs=d_interpolates,
            inputs=interpolates,
            grad_outputs=fake,
            create_graph=True,
            retain_graph=True,
            only_inputs=True,
        )[0]
        # print("a", len(a))
        # print("gra", gradients)
        # print(gradients.shape)
        gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
        return gradient_penalty

    def train(self, dataset):
        torch_dataset = dataset
        dataloader = torch.utils.data.DataLoader(
            torch_dataset,
            batch_size=self.opt.batch_size,
            shuffle=True,
        )
        lambda_gp = 10

        batches_done = 0
        for epoch in range(self.opt.n_epochs):
            for i, (imgs, _) in enumerate(dataloader):

                # Configure input
                real_imgs = Variable(imgs.type(self.Tensor))

                # ---------------------
                #  Train Discriminator
                # ---------------------

                self.optimizer_D.zero_grad()
                # print("real",real_imgs.shape)
                # Sample noise as generator input
                z = Variable(self.Tensor(np.random.rand(imgs.shape[0], self.opt.latent_dim)))
                # print("z  ",z.shape)
                # print("z", z.cpu().data.numpy())
                # print("z",z.shape)
                # Generate a batch of images
                fake_imgs = self.generator(z)
                #print("\nz\n", z)
                #print("\nfake\n",fake_imgs)
                #print("\nfake2\n",fake_imgs/2 + 0.5)
                # Real images
                real_validity = self.discriminator(real_imgs)
                # Fake images
                fake_validity = self.discriminator(fake_imgs)
                # Gradient penalty
                gradient_penalty = self.compute_gradient_penalty(self.discriminator, real_imgs.data, fake_imgs.data)
                # Adversarial loss
                d_loss = -torch.mean(real_validity) + torch.mean(fake_validity) + lambda_gp * gradient_penalty
                #print("\nfake_validity\n", fake_validity)
                #print("\nlambda_gp * gradient_penalty\n", lambda_gp * gradient_penalty)
                #print("\nreal\n", real_validity)
                #print("\nd_loss\n", d_loss)
                d_loss.backward()
                self.optimizer_D.step()

                self.optimizer_G.zero_grad()

                # Train the generator every n_critic steps
                if i % self.opt.n_critic == 0:
                    # -----------------
                    #  Train Generator
                    # -----------------

                    # Generate a batch of images
                    fake_imgs = self.generator(z)
                    # Loss measures generator's ability to fool the discriminator
                    # Train on fake images
                    fake_validity = self.discriminator(fake_imgs)
                    g_loss = -torch.mean(fake_validity)
                    '''
                    print(
                        "[Epoch %d/%d] [Batch %d/%d] [D loss: %f] [G loss: %f]"
                        % (epoch, self.opt.n_epochs, i, len(dataloader), d_loss.item(), g_loss.item())
                    )
                    '''
                    g_loss.backward()
                    self.optimizer_G.step()
                    
                    self.loss_data[0][epoch*int(self.pop_size/self.opt.batch_size/self.opt.n_critic) + int(i/self.opt.n_critic)] = d_loss
                    self.loss_data[1][epoch*int(self.pop_size/self.opt.batch_size/self.opt.n_critic) + int(i/self.opt.n_critic)] = g_loss

                batches_done += self.opt.n_critic
        self.t = self.t + 1


if __name__ == "__main__":
    w = WGAN(105, 7)
    pop_r = (np.random.random([105, 7]), np.random.random([105, 7]))
    pop_f = (np.random.random([105, 7]), np.random.random([105, 7]))
    pop_obj = [1, 2]
    pop = w.wgan_gp(pop_r, pop_f)
    data = w.loss_data
    plt.cla()
    plt.scatter(range(len(data[1])), data[1])#g
    plt.show()
    plt.scatter(range(len(data[0])), data[0])#d
    #plt.plot(data[0], data[1], 'r-', lw=5)
    plt.pause(0.1)
    #print(data)
    print(pop.shape)
    # print(pop)
    # #print(pop)
