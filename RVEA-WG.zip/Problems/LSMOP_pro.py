import numpy as np
from Public.uniformweight import uniform_point
from scipy.spatial.distance import cdist


# np.seterr(divide='ignore',invalid='ignore')

class Testproblem(object):
    def __init__(self, m=None, d=None, ref_num=100):
        self.nk = 5
        if m is None:
            self.m = 3
        else:
            self.m = m

        if d is None:
            self.d = self.m * 100
        else:
            self.d = d
        self.lower = np.zeros([1, self.d])
        self.upper = np.c_[np.ones([1, self.m - 1]), 10 * np.ones([1, self.d - self.m + 1])]
        self.ref_num = ref_num
        # Calculate the number of variables in each
        c = [3.8 * 0.1 * (1 - 0.1)]
        tmp = [3.8 * 0.1 * (1 - 0.1)]
        for i in range(1, self.m):  # do not include m
            c.append(3.8 * c[- 1] * (1 - c[-1]))
        c = np.array(c)
        print(np.shape(c)[0])
        print(c)
        self.sublen = np.floor(c / np.sum(c) * self.d / self.nk)
        self.len_ = np.r_[0, np.cumsum(self.sublen * self.nk)]
        print(self.len_)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random((in_value, self.d)) * \
                       np.tile(self.upper - self.lower, (in_value, 1)) + \
                       np.tile(self.lower, (in_value, 1))
        pop_obj = np.zeros((np.shape(in_value)[0], self.m))

        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        return f

    def IGD(self, pop_obj):
        return np.mean(np.amin(cdist(self.pf(), pop_obj), axis=1))
    
    def getDimension(self):
        return self.d


class LSMOP1(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)), in_value[:, :m - 1]], axis=1)) * np.c_[
            np.ones((n, 1)), 1 - in_value[:, m - 2::-1]]
        return in_value, pop_obj


def Sphere(x):
    return np.sum(x ** 2, axis=1, keepdims=True)


class LSMOP2(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Giewank(in_value[:,
                                                        int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                            self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Schwefel(in_value[:,
                                                         int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                             self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)), in_value[:, :m - 1]], axis=1)) * np.c_[
            np.ones((n, 1)), 1 - in_value[:, m - 2::-1]]
        return in_value, pop_obj


def Giewank(x):
    f = np.sum(x ** 2, axis=1, keepdims=True) / 4000 - np.prod(
        np.cos(x / np.tile(np.sqrt(np.arange(1, np.shape(x)[1] + 1)), (np.shape(x)[0], 1))), axis=1, keepdims=True) + 1
    return f


def Schwefel(x):
    # f = np.max(np.abs(x), [], 2)
    f = []
    row = np.shape(x)[0]
    Y = np.abs(x).max(axis=1)  # 每行最大值
    I = []
    # print(x[0])
    # print(Y[0])
    for i in range(row):
        I.append(np.abs(x[i]).tolist().index(Y[i]))  # 值对应的列坐标
    f.append(Y.tolist())
    f = np.mat(f)
    print(f)
    print(np.shape(f))
    return np.transpose(f)


class LSMOP3(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Rastrigin(in_value[:,
                                                          int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                              self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Rosenbrock(in_value[:,
                                                           int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                               self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)), in_value[:, :m - 1]], axis=1)) * np.c_[
            np.ones((n, 1)), 1 - in_value[:, m - 2::-1]]
        return in_value, pop_obj


# LSMOP3
def Rastrigin(x):
    f = np.sum(x ** 2 - 10 * np.cos(2 * np.pi * x) + 10, axis=1, keepdims=True)
    return f


def Rosenbrock(x):
    f = np.sum(
        100 * (x[:, :np.shape(x)[1] - 1]) ** 2 - x[:, 1:np.shape(x)[1]] ** 2 + (x[:, :np.shape(x)[1] - 1] - 1) ** 2,
        axis=1, keepdims=True)
    return f


class LSMOP4(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Ackley(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Griewank(in_value[:,
                                                         int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                             self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)), in_value[:, :m - 1]], axis=1)) * np.c_[
            np.ones((n, 1)), 1 - in_value[:, m - 2::-1]]
        return in_value, pop_obj


# LSMOP4
def Ackley(x):
    f = 20 - 20 * np.exp(-0.2 * np.sqrt(np.sum(x ** 2, axis=1, keepdims=True) / np.shape(x)[1])) - np.exp(
        np.sum(np.cos(2 * np.pi * x), axis=1, keepdims=True) / np.shape(x)[1]) + np.exp(1)
    # print(f)
    if np.isnan(f[0]) == True:  # nan值，设置为0
        f = np.zeros([100, 1])
    return f


def Griewank(x):
    f = np.sum(x ** 2, axis=1, keepdims=True) / 4000 - np.prod(
        np.cos(x / np.tile(np.sqrt(np.arange(1, np.shape(x)[1] + 1)), (np.shape(x)[0], 1))), axis=1, keepdims=True) + 1
    return f


# LSMOP5
class LSMOP5(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        # PopDec(:,M:D) = (1+repmat(cos((M:D)./D*pi/2),N,1)).*PopDec(:,M:D) - repmat(PopDec(:,1)*10,1,D-M+1);
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1)) / d * np.pi / 2, (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        # in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
        #     in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g + np.c_[g[:, 1:], np.zeros([n, 1])]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1]) * np.pi / 2], axis=1)) * np.c_[
                      np.ones((n, 1)), 1 - np.sin(in_value[:, m - 2::-1] * np.pi / 2)]

        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        f = f / np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
        return f


class LSMOP6(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        # PopDec(:,M:D) = (1+repmat(cos((M:D)./D*pi/2),N,1)).*PopDec(:,M:D) - repmat(PopDec(:,1)*10,1,D-M+1);
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1)) / d * np.pi / 2, (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        # in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
        #     in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Rosenbrock(in_value[:,
                                                           int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                               self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Schwefel(in_value[:,
                                                         int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                             self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g + np.c_[g[:, 1:], np.zeros([n, 1])]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1]) * np.pi / 2], axis=1)) * np.c_[
                      np.ones((n, 1)), 1 - np.sin(in_value[:, m - 2::-1] * np.pi / 2)]
        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        f = f / np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
        return f


class LSMOP7(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        # PopDec(:,M:D) = (1+repmat(cos((M:D)./D*pi/2),N,1)).*PopDec(:,M:D) - repmat(PopDec(:,1)*10,1,D-M+1);
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1)) / d * np.pi / 2, (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        # in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
        #     in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Ackley(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Rosenbrock(in_value[:,
                                                           int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                               self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g + np.c_[g[:, 1:], np.zeros([n, 1])]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1]) * np.pi / 2], axis=1)) * np.c_[
                      np.ones((n, 1)), 1 - np.sin(in_value[:, m - 2::-1] * np.pi / 2)]
        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        f = f / np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
        return f


class LSMOP8(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        # PopDec(:,M:D) = (1+repmat(cos((M:D)./D*pi/2),N,1)).*PopDec(:,M:D) - repmat(PopDec(:,1)*10,1,D-M+1);
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1)) / d * np.pi / 2, (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        # in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
        #     in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Griewank(in_value[:,
                                                         int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                             self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        g = g / np.tile(self.sublen, (n, 1)) / self.nk
        pop_obj = (1 + g + np.c_[g[:, 1:], np.zeros([n, 1])]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1]) * np.pi / 2], axis=1)) * np.c_[
                      np.ones((n, 1)), 1 - np.sin(in_value[:, m - 2::-1] * np.pi / 2)]
        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        f = f / np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
        return f


class LSMOP9(Testproblem):
    def __init__(self, m, d, ref_num):
        Testproblem.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        print(np.shape(np.tile(np.arange(m, d + 1), (n, 1)) * in_value[:, m - 1:d]))
        print(np.shape(np.tile(in_value[:, :1] * 10, (1, d - m + 1))))
        # PopDec(:,M:D) = (1+repmat(cos((M:D)./D*pi/2),N,1)).*PopDec(:,M:D) - repmat(PopDec(:,1)*10,1,D-M+1);
        in_value[:, m - 1: d] = (1 + np.tile(np.cos(np.arange(m, d + 1)) / d * np.pi / 2, (n, 1))) * in_value[:,
                                                                                                     m - 1: d] - np.tile(
            in_value[:, :1] * 10, (1, d - m + 1))
        # in_value[:, m - 1: d] = (1 + np.tile(np.arange(m, d + 1) / d, (n, 1))) * in_value[:, m - 1:d] - np.tile(
        #     in_value[:, :1] * 10, (1, d - m + 1))
        g = np.zeros([n, m])
        for i in range(0, m + 1, 2):
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Sphere(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        for i in range(1, m, 2):
            print(i)
            for j in range(self.nk):
                g[:, i:i + 1] = g[:, i:i + 1] + Ackley(in_value[:,
                                                       int(self.len_[i] + m - 1 + (j - 1) * self.sublen[i]): int(
                                                           self.len_[i] + m - 1 + j * self.sublen[i])])
        g = 1 + np.sum(g / np.tile(self.sublen, (n, 1)) / self.nk, axis=1, keepdims=True)
        # 初始化popobj
        pop_obj = np.random.random([in_value, self.d])
        pop_obj[:, :m - 1] = in_value[:, :m - 1]
        pop_obj[:, m] = (1 + g + np.c_[g[:, 1:], np.zeros([n, 1])]) * np.fliplr(
            np.cumprod(np.c_[np.ones((n, 1)), np.cos(in_value[:, :m - 1]) * np.pi / 2], axis=1)) * np.c_[
                            np.ones((n, 1)), 1 - np.sin(in_value[:, m - 2::-1] * np.pi / 2)]
        return in_value, pop_obj

    def pf(self):
        interval = [0, 0.251412, 0.631627, 0.859401]
        median = (interval[1] - interval[0]) / (interval[3] - interval[2] + interval[1] - interval[0])
        x = []
        # X(X <= median) = X(X <= median) * (interval(2) - interval(1)) / median + interval(1);
        # X(X > median) = (X(X > median) - median) * (interval(4) - interval(3)) / (1 - median) + interval(3);
        p = []
        return 0


def ReplicatePoint(SampleNum, M):
    if M > 1:
        SampleNum = (np.ceil(SampleNum ** (1 / M))) ** M
        # np.arange(0, 1, 1 / (n - 1))
        Gap = np.arange(0, 1, 1 / (SampleNum ** (1 / M) - 1))
        # eval(sprintf('[%s]=ndgrid(Gap);', sprintf('c%d,', 1: M)))
        # eval(sprintf('W=[%s];', sprintf('c%d(:),', 1: M)))
    else:
        W = np.transpose(np.arange(0, 1, 1 / (SampleNum - 1)))
    return W


if __name__ == "__main__":
    r = LSMOP8(3, 300, 100)
    i, p = r.fit('init', 100)
    pf = r.pf()
    print(np.shape(i))
    n, m = np.shape(pf)

    # x = pf[:, 0]
    # y = pf[:, 1]
    # z = pf[:, 2]
    # fig = plt.figure()
    # ax = Axes3D(fig)
    # ax.scatter(x, y, z, c='r')
    # ax.set_xlabel('f1')
    # ax.set_ylabel('f2')
    # ax.set_zlabel('f3')
    # plt.savefig("dtlz1_std.png", dpi=300)
    # plt.show()

    x = range(1, m + 1)
    # for i in range(n):
    #     plt.plot(x, pf[i, :])
    # plt.xlabel('Dimension No.')
    # plt.ylabel('Value')
    # plt.show()
    # plt.savefig("dtlz1_4.png", dpi=300)

    # print(pf)
    igd = r.IGD(p)
    # print(i)
    # print(p)
    print(igd)
