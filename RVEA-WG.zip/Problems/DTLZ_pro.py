import numpy as np
from Public.uniformweight import uniform_point
from scipy.spatial.distance import cdist
import matplotlib.pyplot as plt


class TestProblem(object):
    def __init__(self, m=None, d=None, ref_num=10000):
        self.m = m
        self.d = d
        self.lower = np.zeros([1, self.d])
        self.upper = np.ones([1, self.d])
        self.ref_num = ref_num

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random((in_value, self.d)) * \
                       np.tile(self.upper - self.lower, (in_value, 1)) + \
                       np.tile(self.lower, (in_value, 1))
        pop_obj = np.zeros((np.shape(in_value)[0], self.m))

        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0] / 2
        return f

    def pop_con(self, pop_dec):
        return np.zeros([np.shape(pop_dec)[0], 1])

    def IGD(self, pop_obj):
        return np.mean(np.amin(cdist(self.pf(), pop_obj), axis=1))
    
    def getDimension(self):
        return self.d


class DTLZ1(TestProblem):
    def __init__(self, m, d, ref_num):
        if m is None:
            self.m = 3
        else:
            self.m = m

        if d is None:
            self.d = self.m + 4
        else:
            self.d = d
        TestProblem.__init__(self, self.m, self.d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        g = 100 * (d - m + 1 + np.sum(
            (in_value[:, m-1:] - 0.5) ** 2 - np.cos(20 * np.pi * (in_value[:, m-1:] - 0.5)),
            axis=1, keepdims=True))
        pop_obj = 0.5 * np.tile(1+g, (1, m)) * np.fliplr(np.cumprod(
            np.c_[np.ones((n, 1)), in_value[:, :m-1]], axis=1)) * \
                  np.c_[np.ones((n, 1)), 1-in_value[:, m-2::-1]]

        return in_value, pop_obj


class DTLZ2(TestProblem):
    def __init__(self, m, d, ref_num):
        if m is None:
            self.m = 3
        else:
            self.m = m

        if d is None:
            self.d = self.m + 9
        else:
            self.d = d
        TestProblem.__init__(self, self.m, self.d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        g = np.sum((in_value[:, m-1:]-0.5)**2, axis=1, keepdims=True)
        pop_obj = np.tile(1+g, (1, m)) * np.fliplr(np.cumprod(np.c_[np.ones((np.shape(g)[0], 1)),
                                                                    np.cos(in_value[:, :m-1]*np.pi/2)], axis=1)) * \
                  np.c_[np.ones((np.shape(g)[0], 1)), np.sin(in_value[:, m-2::-1]*np.pi/2)]

        return in_value, pop_obj

    def pf(self):
        f = uniform_point(self.ref_num * self.m, self.m)[0]
        f /= np.tile(np.sqrt(np.sum(f**2, axis=1, keepdims=True)), (1, self.m))
        return f


class DTLZ3(DTLZ2):
    def __init__(self, m, d, ref_num):
        DTLZ2.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        g = 100 * (d - m + 1 + np.sum(
            ((in_value[:, m - 1:] - 0.5) ** 2 - np.cos(20 * np.pi * (in_value[:, m - 1:] - 0.5))),
            axis=1, keepdims=True))
        pop_obj = np.tile(1+g, (1, m)) * np.fliplr(np.cumprod(np.c_[np.ones((n, 1)),
                                                    np.cos(in_value[:, :m - 1] * np.pi / 2)], axis=1)) * \
                  np.c_[np.ones((n, 1)), np.sin(in_value[:, m-2::-1] * np.pi / 2)]
        return in_value, pop_obj


class DTLZ4(DTLZ2):
    def __init__(self, m, d, ref_num):
        DTLZ2.__init__(self, m, d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        in_value[:, :m - 1] = in_value[:, :m - 1] ** 100
        g = np.sum((in_value[:, m - 1:] - 0.5) ** 2, axis=1, keepdims=True)
        pop_obj = np.tile(1 + g, (1, m)) * np.fliplr(np.cumprod(np.c_[np.ones((np.shape(g)[0], 1)),
                                                                np.cos(in_value[:, :m - 1] * np.pi / 2)], axis=1)) * \
                  np.c_[np.ones((np.shape(g)[0], 1)), np.sin(in_value[:, m-2::-1] * np.pi / 2)]
        return in_value, pop_obj


class DTLZ5(TestProblem):
    def __init__(self, m, d, ref_num):
        if m is None:
            self.m = 3
        else:
            self.m = m

        if d is None:
            self.d = self.m + 9
        else:
            self.d = d
        TestProblem.__init__(self, self.m, self.d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        # g  = sum((PopDec(:,M:end)-0.5).^2,2);
        g = np.sum((in_value[:, m-1:] - 0.5) ** 2, axis=1, keepdims=True)
        temp = np.tile(g, (1, m-2))
        in_value[:, 1:m - 1] = (1 + 2 * temp * in_value[:, 1:m - 1]) / (2 + 2 * temp)
        # PopObj = repmat(1+g,1,M).*fliplr(cumprod([ones(size(g,1),1),cos(PopDec(:,1:M-1)*pi/2)],2))
        # .*[ones(size(g,1),1),sin(PopDec(:,M-1:-1:1)*pi/2)];
        pop_obj = np.tile(1 + g, (1, m)) * np.fliplr(np.cumprod(np.c_[np.ones((np.shape(g)[0], 1)),
                                                                np.cos(in_value[:, :m - 1] * np.pi / 2)], axis=1)) * \
                  np.c_[np.ones((np.shape(g)[0], 1)), np.sin(in_value[:, m-2::-1] * np.pi / 2)]
        return in_value, pop_obj

    # def pf(self):
    #     array = []
    #     n = self.ref_num * self.m
    #     first_row = np.arange(0, 1, 1 / (n - 1)).tolist()
    #     second_row = np.arange(1, 0, -1 / (n - 1)).tolist()
    #     first_row.append(1)
    #     second_row.append(0)
    #     array.append(first_row)
    #     array.append(second_row)
    #     f = np.transpose(np.matrix(array))  # matrix tranpose
    #     f /= np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, np.shape(f)[1]))
    #     f /= np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, self.m))
    #     f = [f[:, np.ones(1, self.m - 2)], f]
    #     # P = P./sqrt(2).^repmat([obj.Global.M-2,obj.Global.M-2:-1:0],size(P,1),1)
    #     row = np.arange(self.m - 2, 0, -1)
    #     row.tolist()
    #     row.append(0)
    #     row.insert(0, self.m - 2)
    #     f /= np.sqrt(2) ** np.tile(np.matrix(row), (np.shape(f)[1], 1))
    #     return f

    def pf(self):
        n = self.ref_num * self.m
        f = np.vstack((np.hstack(((np.arange(0, 1, 1. / (n - 1))), 1.)),
                       np.hstack(((np.arange(1, 0, -1. / (n - 1))), 0.)))).T
        f /= np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, np.shape(f)[1]))
        # f = np.c_[f[:, np.ones(1, self.m-2)], f]
        for i in range(self.m-2):
            f = np.c_[f[:, 0], f]
        # print(f)
        # print(np.hstack((self.m-2, np.arange(self.m-2, -1, -1))))
        f = f/np.sqrt(2)*np.tile(np.hstack((self.m-2, np.arange(self.m-2, -1, -1))), (np.shape(f)[0], 1))
        return f


class DTLZ6(TestProblem):
    def __init__(self, m, d, ref_num):
        if m is None:
            self.m = 3
        else:
            self.m = m

        if d is None:
            self.d = self.m + 9
        else:
            self.d = d
        TestProblem.__init__(self, self.m, self.d, ref_num)

    def fit(self, operation, in_value):
        if operation == 'init':
            in_value = np.random.random([in_value, self.d])
        n, d = np.shape(in_value)
        m = self.m
        g = np.sum((in_value[:, m - 1:]) ** 0.1, axis=1, keepdims=True)
        Temp = np.tile(g, (1, self.m - 2))
        in_value[:, 1:m - 1] = (1 + 2 * Temp * in_value[:, 1:m - 1]) / (2 + 2 * Temp)
        # PopObj = repmat(1+g,1,M).*fliplr(cumprod([ones(size(g,1),1),cos(PopDec(:,1:M-1)*pi/2)],2))
        # .*[ones(size(g,1),1),sin(PopDec(:,M-1:-1:1)*pi/2)];
        pop_obj = np.tile(1 + g, (1, m)) * np.fliplr(np.cumprod(np.c_[np.ones((np.shape(g)[0], 1)),
                                                                      np.cos(in_value[:, :m - 1] * np.pi / 2)],
                                                                axis=1)) * \
                  np.c_[np.ones((np.shape(g)[0], 1)), np.sin(np.fliplr(in_value[:, :m - 1]) * np.pi / 2)]
        return in_value, pop_obj

    def pf(self):
        array = []
        n = self.ref_num * self.m
        first_row = np.arange(0, 1, 1 / (n - 1)).tolist()
        second_row = np.arange(1, 0, -1 / (n - 1)).tolist()
        first_row.append(1)
        second_row.append(0)
        array.append(first_row)
        array.append(second_row)
        f = np.transpose(np.matrix(array))  # matrix tranpose
        f /= np.tile(np.sqrt(np.sum(f ** 2, axis=1, keepdims=True)), (1, np.shape(f)[1]))
        f = [f[:, np.ones(1, self.m - 2)], f]
        # P = P./sqrt(2).^repmat([obj.Global.M-2,obj.Global.M-2:-1:0],size(P,1),1)
        row = np.arange(self.m - 2, 0, -1)
        row.tolist()
        row.append(0)
        row.insert(0, self.m - 2)
        f /= np.sqrt(2) ** np.tile(np.matrix(row), (np.shape(f)[1], 1))
        return f


class DTLZ8(TestProblem):
    def __init__(self, m, d, ref_num):
        if m is None:
            self.m = 3
        else:
            self.m = m

        if d is None:
            self.d = self.m * 10
        else:
            self.d = d
        TestProblem.__init__(self, self.m, self.d, ref_num)
        self.d = np.ceil(self.d/self.m)


if __name__ == "__main__":
    r = DTLZ3(3, 9, 105)
    i, p = r.fit('init', 105)
    pf = r.pf()
    n, m = np.shape(pf)

    # x = pf[:, 0]
    # y = pf[:, 1]
    # z = pf[:, 2]
    # fig = plt.figure()
    # ax = Axes3D(fig)
    # ax.scatter(x, y, z, c='r')
    # ax.set_xlabel('f1')
    # ax.set_ylabel('f2')
    # ax.set_zlabel('f3')
    # plt.savefig("dtlz1_std.png", dpi=300)
    # plt.show()

    x = range(1, m + 1)
    # for i in range(n):
    #     plt.plot(x, pf[i, :])
    # plt.xlabel('Dimension No.')
    # plt.ylabel('Value')
    # plt.show()
    # plt.savefig("dtlz3.png", dpi=300)

    # print(pf)
    igd = r.IGD(p)
    print('invale')
    print(i)
    print('obj')
    print(p)
    print('lgd')
    print(igd)
    a = np.zeros([105, 9])
    print(r.fit("a", a))
