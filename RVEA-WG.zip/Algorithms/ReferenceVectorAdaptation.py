import numpy as np


class ReferenceVectorAdaptation:

    def __init__(self, pop_obj, v):
        self.pop_obj = pop_obj
        self.v = v

    def adapter(self):

        v_temp = self.v * np.tile((self.pop_obj.max(0) - self.pop_obj.min(0)), (len(self.v), 1))
        next_v = self.v.astype(float)

        for i in range(len(self.v)):
            next_v[i] = v_temp[i] / np.sqrt(np.sum(v_temp[i, :]**2))
        return next_v


if __name__ == '__main__':
    obj = np.array([[12., 2, 3], [2, 4, 5]])
    v = np.array([[2., 1, 4], [5, 5, 7]])

    refer = ReferenceVectorAdaptation(obj, v)
    n = refer.adapter()
    print(n)
