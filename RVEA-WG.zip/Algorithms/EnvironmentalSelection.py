import numpy as np
from scipy.spatial.distance import pdist


class EnvironmentalSelection:
    def __init__(self, population, pop_obj, cons, v, theta):
        self.population = np.array(population)
        self.pop_obj = np.array(pop_obj)
        self.cons = cons
        self.v = v
        self.theta = theta

    def selection(self):
        n, m = np.shape(self.pop_obj)
        nv = np.shape(self.v)[0]
        obj = self.pop_obj
        
        np.random.shuffle(obj)

        obj = obj - np.tile(obj.min(0), (n, 1))

        cv = np.sum((self.cons > 0)*self.cons, axis=1)

        cosine = np.zeros((nv, nv))
        for i in range(nv):
            for j in range(nv):
                cosine[i, j] = 1 - pdist(np.vstack([self.v[j], self.v[i]]), 'cosine')[0]
        np.fill_diagonal(cosine, 0)
        gamma = np.arccos(cosine).min(1)

        angle = np.zeros((n, nv))
        for i in range(n):
            for j in range(nv):
                angle[i, j] = np.arccos(1 - pdist(np.vstack([obj[i, :], self.v[j, :]]), 'cosine')[0])

        associate = np.argmin(angle, axis=1)

        next_ind = np.full([1, nv], -1)
        next_temp = np.full([1, nv], -1)

        for i in np.unique(associate):
            # print("i", i)
            current1 = [j for (j, val) in enumerate(list(associate)) if associate[j] == i and cv[j] == 0]
            #print("current1", current1)
            current2 = [j for (j, val) in enumerate(list(associate)) if associate[j] == i and cv[j] != 0]
            if current1:
                apd = (1+m*self.theta*angle[current1, i]/gamma[i]) * np.sqrt(np.sum(obj[current1, :]**2,
                                                                                    axis=1, keepdims=True).T)
                # print("apd", apd)
                best = np.argmin(apd)
                # print("best", best)
                next_ind[0, i] = current1[int(best)]
            elif current2:
                best = np.argmin(cv[current2])
                next_ind[0, i] = current2[int(best)]

        next_ind = next_ind[next_ind != -1]
        #print("next", next_ind)
        fake_ind = np.setdiff1d(np.arange(n), next_ind)

        next_pop_dec = self.population[next_ind]
        # next_pop_dec = np.vstack([next_pop_dec, np.zeros([n-np.shape(next_pop_dec)[0], np.shape(self.population)[1]])])
        next_pop_obj = self.pop_obj[next_ind]
        fake_dec = self.population[fake_ind]
        fake_obj = self.pop_obj[fake_ind]

        return (next_pop_dec, next_pop_obj), (fake_dec, fake_obj)


if __name__ == '__main__':
    pop = np.array([[1., 2., 3., 4.], [2, 3, 8, 1], [6, 12, 34, 1], [4, 46, 34, 14], [9, 3, 3, 7], [5, 22, 23, 25]])
    obj = np.array([[2., 2, 10], [0.2, 11, 1], [15, 25, 8.2], [4, 5, 6], [9, 21, 30], [7, 10, 5]])
    theta = 0.25
    print("pop", pop)
    print("obj", obj)

    vector = np.array([[2., 1, 4], [5, 4, 7], [10, 8, 5]])
    for p in range(3):
        vector[p] = vector[p] / np.sqrt(np.sum(vector[p] ** 2))

    con = np.zeros([6, 1])
    print("vec",vector)
    e = EnvironmentalSelection(pop, obj, con, vector, theta)
    next_p, f = e.selection()
    print("next",next_p)
    print("f",f)
