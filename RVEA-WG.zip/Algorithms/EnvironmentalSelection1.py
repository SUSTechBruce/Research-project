import numpy as np
from scipy.spatial.distance import pdist


class EnvironmentalSelection:
    def __init__(self, population, pop_obj, v, theta):
        self.population = np.array(population)
        self.pop_obj = np.array(pop_obj)
        self.v = v
        self.theta = theta

    def selection(self):
        n, m = np.shape(self.pop_obj)
        nv = np.shape(self.v)[0]

        z_min = self.pop_obj.min(0)
        pop_obj_t = self.pop_obj
        for i in range(n):
            pop_obj_t[i, :] = self.pop_obj[i, :] - z_min

        cosine = np.zeros((n, nv))
        for i in range(n):
            for j in range(nv):
                # if pop_obj_t[i, :].all() == 0:
                #     cosine[i, j] = 1
                # else:
                cosine[i, j] = 1 - pdist(np.vstack([pop_obj_t[i, :], self.v[j, :]]), 'cosine')[0]

                # print(cosine[i, j])
                # cosine[i, j] = np.dot(pop_obj_t[i, :], self.v[j, :]) / (np.linalg.norm(pop_obj_t[i, :]))
                # if i == 0:
                #     print('1')
                #     print(cosine[i, j])
                #     print('2')
                #     print(pdist(np.vstack([pop_obj_t[i, :], self.v[j, :]]), 'cosine')[0])

        # print('cos')
        # print(cosine)
        # print('cos1')
        # print(cosine[0, :])
        theta_t = np.arccos(cosine)
        # print('theta')
        # print(theta_t)
        # print('theta1')
        # print(theta_t[0, :])

        P_t = [[] for i in range(0, nv)]
        index = [[] for i in range(0, nv)]

        for i in range(n):
            k = int(np.argmax(cosine[i, :]))
            P_t[k].append(self.population[i, :])
            index[k].append(i)
        P_t = np.array(P_t)
        index = np.array(index)

        # print('index')
        # print(np.shape(index))

        gamma = np.zeros((nv, 1))
        gamma2 = np.zeros((nv, nv))
        min_d_list = np.zeros((nv, 1))

        for j in range(nv):
            min_d = 0
            for i in range(nv):
                if i == j:
                    continue
                dis = 1 - pdist(np.vstack([self.v[j], self.v[i]]), 'cosine')[0]
                gamma2[j, i] = dis
                if dis > min_d:
                    gamma[j] = dis
                    min_d = dis
                min_d_list[j] = min_d

        d = np.full((len(pop_obj_t), nv), 10000.)
        for j in range(nv):
            for i in range(len(P_t[j])):
                d[i, j] = (1 + m * self.theta * theta_t[i, j]/gamma[j]) * np.sqrt(np.sum(pop_obj_t[i, :]**2))

        # print(np.shape(d))

        next_pop_dec = np.zeros((nv, np.shape(self.population)[1]))
        next_pop_obj = np.zeros((nv, np.shape(self.pop_obj)[1]))
        li = list(range(n))
        for j in range(nv):
            if len(index[j]) == 0:
                continue
            k = np.argmin(d[:, j])
            i = index[j][k]
            li.remove(i)
            next_pop_dec[j] = self.population[i]
            next_pop_obj[j] = self.pop_obj[i]

        # print(next_pop_obj)
        # print(np.shape(next_pop_obj))
        # print(np.shape(self.pop_obj[li]))

        # next_pop = (next_pop_dec, next_pop_obj)
        fake = (self.population[li], self.pop_obj[li])

        return next_pop_dec, fake


if __name__ == '__main__':
    pop = np.array([[1., 2., 3., 4.], [2, 3, 8, 1], [6, 12, 34, 1], [4, 46, 34, 14], [9, 3, 3, 7], [5, 22, 23, 25]])
    obj = np.array([[2., 2, 10], [0.2, 11, 1], [15, 25, 8.2], [4, 5, 6], [9, 21, 30], [7, 10, 5]])
    theta = 1.0
    vector = np.array([[2., 1, 4], [5, 4, 7], [10, 8, 5]])
    for p in range(3):
        vector[p] = vector[p] / np.sqrt(np.sum(vector[p] ** 2))

    print("vec",vector)
    e = EnvironmentalSelection(pop, obj, vector, theta)
    next_p, f = e.selection()
    print("next",next_p)
    print("f",f)
