from Problems.DTLZ_pro import *
from Problems.LSMOP_pro import *


class Individual:
    def __init__(self, pro):
        self.pro = pro

    def initialize(self, d=None, pop_size=100, m=None):
        global mos_pro, population
        if self.pro == "DTLZ1":
            mos_pro = DTLZ1(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "DTLZ2":
            mos_pro = DTLZ2(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "DTLZ3":
            mos_pro = DTLZ3(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "DTLZ4":
            mos_pro = DTLZ4(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "DTLZ5":
            mos_pro = DTLZ5(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "DTLZ6":
            mos_pro = DTLZ6(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "DTLZ8":
            mos_pro = DTLZ8(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "LSMOP1":
            mos_pro = LSMOP1(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "LSMOP2":
            mos_pro = LSMOP2(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "LSMOP3":
            mos_pro = LSMOP3(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "LSMOP4":
            mos_pro = LSMOP4(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "LSMOP5":
            mos_pro = LSMOP5(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)
        
        if self.pro == "LSMOP6":
            mos_pro = LSMOP6(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)
        
        if self.pro == "LSMOP7":
            mos_pro = LSMOP7(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)

        if self.pro == "LSMOP8":
            mos_pro = LSMOP8(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)
        
        if self.pro == "LSMOP9":
            mos_pro = LSMOP9(m, d, pop_size)
            population = mos_pro.fit(operation ='init', in_value=pop_size)
        
        return mos_pro, population


if __name__ == "__main__":
    vec = Individual('DTLZ1')

