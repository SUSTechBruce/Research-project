from Algorithms.RVEA import *
import time
import scipy.io as sio
import os
from Public.Individual import *
from Operators import *

parameter = {'algorithm': 'RVEA', 'problem': 'DTLZ1',
             'max_gen': 15, 'N': 105, 'M': 3, 'D': 7, 'run': 10}
problem_list = ['DTLZ1', 'DTLZ2', 'DTLZ3', 'DTLZ4', 'DTLZ5',  'LSMOP1', 
                'LSMOP2', 'LSMOP3', 'LSMOP4', 'LSMOP5', 'LSMOP6', 'LSMOP7', 'LSMOP8', 'LSMOP9']
M_list = [3, 6, 8, 10]
N_list = [105, 132, 156, 275]
start = time.time()
path = os.path.abspath('.')

for j in range(0, 5):
    for k in range(len(M_list)):
        parameter['problem'] = problem_list[j]
        parameter['N'] = N_list[k]
        parameter['M'] = M_list[k]
        individual = Individual(parameter['problem'])
        pro, population = individual.initialize(m=parameter['M'])
        parameter['D'] = pro.getDimension()   
        print(parameter['problem'], parameter['M'])
        for i in range(parameter['run']):
            print("Run " + str(i+1))
            name = path + '/Data/' + parameter['problem'] + '/' + '_{0}_{1}'.format(parameter['M'], i)
            fig = path + '/Data/' + parameter['problem'] + '/' + '_{0}_{1}.png'.format(parameter['M'], i)
            rvea = RVEA(parameter['N'], parameter['D'], parameter['M'], parameter['max_gen'], parameter['problem'])
            pop, igd, pf = rvea.run
            #print(pf)
            #print(pop[1])
            print(igd)
            sio.savemat(name, {'obj': pop[1], 'igd_last': igd[-1], 'igd': igd, 'pf': pf})
            plot(pop[1], pf, fig)
      


time = time.time() - start
print(time)





